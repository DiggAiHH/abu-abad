import{c}from"./index-C-EJlQ3S.js";const o=c("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{o as C};
//# sourceMappingURL=check-DMSb_2sI.js.map
