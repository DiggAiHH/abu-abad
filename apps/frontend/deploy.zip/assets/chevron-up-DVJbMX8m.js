import{c as e}from"./index-C-EJlQ3S.js";const r=e("ChevronUp",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]);export{r as C};
//# sourceMappingURL=chevron-up-DVJbMX8m.js.map
