import{c as e}from"./index-C-EJlQ3S.js";const s=e("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]]);export{s as M};
//# sourceMappingURL=message-square-CkYaVDXG.js.map
