import{c as o}from"./index-C-EJlQ3S.js";const t=o("Moon",[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]]);export{t as M};
//# sourceMappingURL=moon-B_7zSVN6.js.map
