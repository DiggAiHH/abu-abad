import{c as e}from"./index-C-EJlQ3S.js";const a=e("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);export{a as P};
//# sourceMappingURL=plus-AQLSUt58.js.map
