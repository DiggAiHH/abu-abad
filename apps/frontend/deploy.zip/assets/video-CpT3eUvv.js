import{c as e}from"./index-C-EJlQ3S.js";const t=e("Video",[["path",{d:"m22 8-6 4 6 4V8Z",key:"50v9me"}],["rect",{width:"14",height:"12",x:"2",y:"6",rx:"2",ry:"2",key:"1rqjg6"}]]);export{t as V};
//# sourceMappingURL=video-CpT3eUvv.js.map
